import numpy as np
from utils import *

def preprocess(X, Y):
	''' TASK 0
	X = input feature matrix [N X D] 
	Y = output values [N X 1]
	Convert data X, Y obtained from read_data() to a usable format by gradient descent function
	Return the processed X, Y that can be directly passed to grad_descent function
	NOTE: X has first column denote index of data point. Ignore that column 
	and add constant 1 instead (for bias part of feature set)
	'''
	columns = len(X[0])
	rows = len(X)
	#print(columns)
	#print(rows)
	#for i in X:
	#	i[0]=1
	output_array=np.ones((rows,1))
	new_column=np.zeros((rows,1))
	

	for j in range(1,columns):
		if isinstance(X[:,j][0], str)==False:
			avg=np.mean(X[:,j],axis=0)
			std=np.std(X[:,j],axis=0)
			for i in range(rows):
				new_column[i,0]=(X[i,j]-avg)/std
			output_array=np.concatenate((output_array,new_column),axis=1)
		else:
			output_array=np.concatenate((output_array,one_hot_encode(X[:,j],list(set(X[:,j])))),axis=1)			  
	return output_array.astype(float),Y.astype(float)
	#pass

def grad_ridge(W, X, Y, _lambda):
	'''  TASK 2
	W = weight vector [D X 1]
	X = input feature matrix [N X D]
	Y = output values [N X 1]
	_lambda = scalar parameter lambda
	Return the gradient of ridge objective function (||Y - X W||^2  + lambda*||w||^2 )
	'''
	#print(len(W))
	#print(type(X))
	Z=np.subtract(Y,np.matmul(X,W))
	gradient_of_ridge=(-2)*np.matmul(np.transpose(X),Z)+2*_lambda*W
	return gradient_of_ridge

def ridge_grad_descent(X, Y, _lambda, max_iter=30000, lr=0.00001, epsilon = 1e-4):
	''' TASK 2
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	_lambda 	= scalar parameter lambda
	max_iter 	= maximum number of iterations of gradient descent to run in case of no convergence
	lr 			= learning rate
	epsilon 	= gradient norm below which we can say that the algorithm has converged 
	Return the trained weight vector [D X 1] after performing gradient descent using Ridge Loss Function 
	NOTE: You may precompue some values to make computation faster
	'''
	columns = len(X[0])
	rows = len(X)
	weights = np.random.rand(columns,1)
	n=len(weights)

	def Has_converged(old_weights,new_weights):
		for i in range(n):
			if epsilon < abs(old_weights[i]-new_weights[i]):
				return False
		return True

	for i in range(max_iter):
		old_weights = weights.copy() #so that old_weights will not get updated as we update weights
		weights = weights- lr * grad_ridge(weights, X, Y, _lambda)
		if Has_converged(old_weights, weights):
			return weights
	#pass


def k_fold_cross_validation(X, Y, k, lambdas, algo):
	''' TASK 3
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	k 			= number of splits to perform while doing kfold cross validation
	lambdas 	= list of scalar parameter lambda
	algo 		= one of {coord_grad_descent, ridge_grad_descent}
	Return a list of average SSE values (on validation set) across various datasets obtained from k equal splits in X, Y 
	on each of the lambdas given 
	'''
	pass

def coord_grad_descent(X, Y, _lambda, max_iter=1):
	''' TASK 4
	X 			= input feature matrix [N X D]
	Y 			= output values [N X 1]
	_lambda 	= scalar parameter lambda
	max_iter 	= maximum number of iterations of gradient descent to run in case of no convergence
	Return the trained weight vector [D X 1] after performing gradient descent using Ridge Loss Function 
	'''
	columns = len(X[0])
	rows = len(X)
	weights = np.ones((columns,1))
	n=len(weights)
	#Z=np.subtract(Y,np.matmul(X,weights))
	#rss=(-2)*np.matmul(np.transpose(X),Z)
	#print(rss)
	#+2*_lambda*W
	P=0
	rss=0
	z=0
	for k in range(max_iter):
		print(k)
		for j in range(columns):	
			for i in range(rows):	
				Z=np.subtract(Y[i],np.matmul(X[i],weights)) #single element
				P+=2*(X[i,j]**2)
				rss+=(-2)*(X[i,j]*Z+(X[i,j]**2)*weights[j])
				rss+=_lambda
				z=rss/P
				if z>=0:
					weights[j]=z
				else:
					rss-=2*_lambda
					z=rss/P
					if z<0:
						weights[j]=z
					else:
					 	weights[j]=0		
						
	return weights		

	#pass

if __name__ == "__main__":
	# Do your testing for Kfold Cross Validation in by experimenting with the code below 
	X, Y = read_data("./dataset/train.csv")
	X, Y = preprocess(X, Y)
	trainX, trainY, testX, testY = separate_data(X, Y)
	
	lambdas = [...] # Assign a suitable list Task 5 need best SSE on test data so tune lambda accordingly
	scores = k_fold_cross_validation(trainX, trainY, 6, lambdas, ridge_grad_descent)
	plot_kfold(lambdas, scores)