import numpy as np
import sys

class MDP():
	
	def __init__(self, file):
		
		f = open(file)
		lines = f.readlines()
		data = [line.split() for line in lines]

		self.numStates = int(data[0][1]) #first line's second word
		self.numActions = int(data[1][1])  
		self.start = int(data[2][1]) 
		self.end = int(data[3][1])  
		self.discount = float(data[-1][1])  #last line's second word
		self.transitions = {}  

		for tr in data[4:-1]:  
			i,j,k,l,m = int(tr[1]), int(tr[2]), int(tr[3]), float(tr[4]),float(tr[5])
			
			if i not in self.transitions:
				self.transitions[i] = {}

			if j not in self.transitions[i]:
				self.transitions[i][j] = {}

			self.transitions[i][j][k] = (m,l)

	def valueIteration(self):

		states=self.numStates
		V = np.zeros(states)
		V[self.end] = 1e100
		Pi=[]
		for i in range(states):
			Pi.append(-1)

		V_Previous = V.copy()
		V_New = V_Previous.copy()	

		iterations = 0
		while iterations==0 or abs((V-V_Previous).max()) >=10**-16 :

			iterations += 1
			V_New = V.copy()
			V_Previous = V.copy()

			for i in range(states):
				if i == self.end:
					continue

				transition = self.transitions.get(i, {})
				items=transition.items()
				V[i] = -1e100

				for j, k in items:
					reward = 0.0
					for l, pr in k.items():
						reward += pr[0]*(pr[1]+self.discount*V_New[l]*(l!=self.end))

					if reward > V[i]:

						V[i] = reward
						Pi[i] = j

		return V, Pi, iterations


mdp = MDP(sys.argv[1])
states=mdp.numStates
V, pi, iterations = mdp.valueIteration()

for i in range(states):
	print('%.12f %d'%(V[i]*(i!=mdp.end), pi[i])) #print V till 12th digits ,pi

print('iterations', iterations)