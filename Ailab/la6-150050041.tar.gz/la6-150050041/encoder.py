import sys
f = open(sys.argv[1])
lines = f.readlines()
f.close()

Index_Array = {}
states = []
start = None
end = None



array = [[int(i) for i in j.strip('\n').split(' ')] for j in lines]
n = len(array)
m = len(array[0])
for i in range(n):
	for j in range(m):
		if array[i][j]!=1:
			if array[i][j]==2:
				start = (i,j)
			elif array[i][j]==3:
				end = (i,j)
			Index_Array[(i,j)] = len(Index_Array)
			states.append((i,j))

print('numStates', len(states))
print('numActions', 4)
print('start', Index_Array[start])
print('end', Index_Array[end])

for i,j in states:

	new_array = []

	if (i+1, j) in Index_Array:
		new_array.append(((i+1,j),1))

	if (i-1, j) in Index_Array:
		new_array.append(((i-1,j),2))

	if (i, j+1) in Index_Array:
		new_array.append(((i,j+1),3))

	if (i, j-1) in Index_Array:
		new_array.append(((i,j-1),0))

	if len(new_array)==0:
		continue

	else:
		for k, l in new_array:
			print('transitions', Index_Array[(i,j)], l, Index_Array[k], -1 + 1e100*(k==end), 1.0/len(new_array))
print('discount 0.99')
