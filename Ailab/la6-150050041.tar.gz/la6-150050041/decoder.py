import sys
f = open(sys.argv[1])
lines = f.readlines()
f.close()

Index_Array = {}
states = []
start = None
end = None



array = [[int(i) for i in j.strip('\n').split(' ')] for j in lines]
n = len(array)
m = len(array[0])
for i in range(n):
	for j in range(m):
		if array[i][j]!=1:
			if array[i][j]==2:
				start = (i,j)
			elif array[i][j]==3:
				end = (i,j)
			Index_Array[(i,j)] = len(Index_Array)
			states.append((i,j))

new_f = open(sys.argv[2])
lines = new_f.readlines()

array = [[eval(i) for i in j.strip('\n').split(' ')] for j in lines[:-1]]
begin_ = Index_Array[start]
actions = []

while begin_ != Index_Array[end] and len(actions)<n*m:
	a = array[begin_][1]
	if a==-1:
		break
	actions.append('WSNE-'[a])
	i,j = states[begin_]
	
	if a==0:
		begin_ = Index_Array[(i,j-1)]
	elif a==1:
		begin_ = Index_Array[(i+1,j)]
	elif a==2:
		begin_ = Index_Array[(i-1,j)]
	elif a==3:
		begin_ = Index_Array[(i,j+1)]

print(' '.join(actions))


