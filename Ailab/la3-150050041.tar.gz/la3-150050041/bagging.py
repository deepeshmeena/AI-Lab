import util
import numpy as np
import sys
import random

PRINT = True

###### DON'T CHANGE THE SEEDS ##########
random.seed(42)
np.random.seed(42)

class BaggingClassifier:
	"""
	Bagging classifier.

	Note that the variable 'datum' in this code refers to a counter of features
	(not to a raw samples.Datum).
	
	"""

	def __init__( self, legalLabels, max_iterations, weak_classifier, ratio, num_classifiers):

		self.ratio = ratio
		self.num_classifiers = num_classifiers
		self.classifiers = [weak_classifier(legalLabels, max_iterations) for _ in range(self.num_classifiers)]

	def train( self, trainingData, trainingLabels):
		"""
		The training loop samples from the data "num_classifiers" time. Size of each sample is
		specified by "ratio". So len(sample)/len(trainingData) should equal ratio. 
		"""

		self.features = trainingData[0].keys()
		#"*** YOUR CODE HERE ***"
		#util.raiseNotDefined()
		#m=self.num_classifiers
		list_of_labels=[]
		list_of_data=[]
		length_sample=int(self.ratio*len(trainingData))
		l=range(length_sample) #index from 0 to N'
		for i in range(self.num_classifiers): 
			index=random.sample(l,length_sample)
			for j in index:
				list_of_labels.append(trainingLabels[j])
				list_of_data.append(trainingData[j])
			self.classifiers[i].train(list_of_data,list_of_labels,None)
			#print i




	def classify( self, data):
		"""
		Classifies each datum as the label that most closely matches the prototype vector
		for that label. This is done by taking a polling over the weak classifiers already trained.
		See the assignment description for details.

		Recall that a datum is a util.counter.

		The function should return a list of labels where each label should be one of legaLabels.
		"""

		#"*** YOUR CODE HERE ***"
		#util.raiseNotDefined()
		output=[]
		for i in range(len(data)):
			guess=0
			for j in range(self.num_classifiers):
				guess+=self.classifiers[j].classify([data[i]])[0]
			if guess>=0:
				output.append(1)	
			else:
				output.append(-1)
		return output        

